module.exports = {
  makers: [
    {
      name: '@electron-forge/maker-zip',
      platforms: ['linux', 'win32'],
      config: {
        // the config can be an object
      }
    },
  ]
};
