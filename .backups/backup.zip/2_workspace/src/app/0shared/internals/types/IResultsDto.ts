

export interface IResultsDto {

  totalSoilWeight: number;

  tamizDiameterProm: number[];

  soilPortions: number[];

  MWDs: number[];

  MWDTotal: number;

}






