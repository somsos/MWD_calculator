export interface IRowSample {
  soilWeight: number,
  tamizDiameter: number
}

export type MapSamples = Map<number,  IRowSample>;
